
<?php
// Configuration file
$conn=mysqli_connect("localhost","root","","crud_operation");

if($conn)
{
	
}
else
{
	echo "Failed to connect";
}
?>